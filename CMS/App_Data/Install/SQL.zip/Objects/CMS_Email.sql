SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Email](
	[EmailID] [int] IDENTITY(1,1) NOT NULL,
	[EmailFrom] [nvarchar](254) NOT NULL,
	[EmailTo] [nvarchar](998) NULL,
	[EmailCc] [nvarchar](998) NULL,
	[EmailBcc] [nvarchar](998) NULL,
	[EmailSubject] [nvarchar](450) NOT NULL,
	[EmailBody] [nvarchar](max) NULL,
	[EmailPlainTextBody] [nvarchar](max) NULL,
	[EmailFormat] [int] NOT NULL,
	[EmailPriority] [int] NOT NULL,
	[EmailSiteID] [int] NULL,
	[EmailLastSendResult] [nvarchar](max) NULL,
	[EmailLastSendAttempt] [datetime2](7) NULL,
	[EmailGUID] [uniqueidentifier] NOT NULL,
	[EmailLastModified] [datetime2](7) NOT NULL,
	[EmailStatus] [int] NULL,
	[EmailIsMass] [bit] NULL,
	[EmailReplyTo] [nvarchar](254) NULL,
	[EmailHeaders] [nvarchar](max) NULL,
	[EmailCreated] [datetime2](7) NULL,
 CONSTRAINT [PK_CMS_Email] PRIMARY KEY CLUSTERED 
(
	[EmailID] ASC
)
)

GO
SET ANSI_PADDING ON

GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_Email_EmailPriority_EmailID] ON [dbo].[CMS_Email]
(
	[EmailPriority] DESC,
	[EmailID] ASC
)
INCLUDE ( 	[EmailStatus],
	[EmailLastSendResult])
GO
ALTER TABLE [dbo].[CMS_Email] ADD  CONSTRAINT [DEFAULT_CMS_Email_EmailFrom]  DEFAULT (N'') FOR [EmailFrom]
GO
ALTER TABLE [dbo].[CMS_Email] ADD  CONSTRAINT [DEFAULT_CMS_Email_EmailSubject]  DEFAULT ('') FOR [EmailSubject]
GO
ALTER TABLE [dbo].[CMS_Email] ADD  CONSTRAINT [DEFAULT_CMS_Email_EmailLastModified]  DEFAULT ('6/17/2016 10:11:21 AM') FOR [EmailLastModified]
GO
ALTER TABLE [dbo].[CMS_Email] ADD  CONSTRAINT [DEFAULT_CMS_Email_EmailIsMass]  DEFAULT ((1)) FOR [EmailIsMass]
GO
