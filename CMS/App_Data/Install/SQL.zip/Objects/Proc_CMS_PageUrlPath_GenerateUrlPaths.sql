SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_PageUrlPath_GenerateUrlPaths]
	@StartingNodeID INT = NULL,
	@SiteID INT,
	@CultureCodes Type_CMS_StringTable READONLY,
	@LastModified DATETIME,
	@UseCulturePrefix BIT,
	@DefaultCultureCode NVARCHAR(50),
	@HidePrefixForDefaultCulture BIT
AS

BEGIN

	DECLARE @PageTypes TABLE(
		[ID] INT NOT NULL, 
		[HasUrl] BIT NOT NULL)

	INSERT INTO @PageTypes ([ID], [HasUrl])
		SELECT 
			[ClassID], 
			[ClassHasURL] 
		FROM [CMS_Class] 
		WHERE [ClassID] IN (SELECT [ClassID] FROM [CMS_ClassSite] WHERE [SiteID] = @SiteID)

	DECLARE @PreparedPaths TABLE (
		[CultureCode] NVARCHAR(50) NOT NULL, 
		[NodeID] INT NOT NULL, 
		[UrlPath] NVARCHAR(2000) NOT NULL, 
		[NodeSiteID] INT NOT NULL,
		[IsRootPath] BIT NOT NULL
	)

	DECLARE @PrefixPath NVARCHAR(2000) = ''

	-- Builds parent URL path prefix from node aliases. 
	-- In the prefix participate only node aliases of pages having URL
	IF @StartingNodeID IS NOT NULL
	BEGIN
		;WITH ParentPaths AS (
			SELECT       
				[NodeID], 
				[NodeParentID],
				[NodeSiteID],
				[NodeAliasPath],
				CAST('' AS NVARCHAR(2000)) AS ParentPath		-- Current path does not participate in prefix
			FROM [CMS_Tree]
			WHERE
				[NodeID] = @StartingNodeID

			UNION ALL

			SELECT 
				[T].[NodeID], 
				[T].[NodeParentID],
				[T].[NodeSiteID],
				[T].[NodeAliasPath],
				CAST(CASE HasUrl 
					 WHEN 1 THEN CASE [P].[ParentPath] WHEN '' THEN [T].[NodeAlias] ELSE [T].[NodeAlias] + '/' + [P].[ParentPath] END
					 ELSE [P].[ParentPath] END AS NVARCHAR(2000)) 
					 AS ParentPath
			FROM 
				[CMS_Tree] AS [T] 
					INNER JOIN ParentPaths [P] ON [T].[NodeID] = [P].[NodeParentID]
					INNER JOIN @PageTypes ON [T].[NodeClassID] = [ID]
		)
		SELECT TOP 1 @PrefixPath = [ParentPath] FROM ParentPaths
		WHERE [NodeParentID] IS NULL
	END

	-- Build culture paths for all descendants having URL
	;WITH paths AS (
		SELECT       
			[NodeID], 
			CAST(CASE HasUrl 
			     WHEN 1 THEN CASE @PrefixPath WHEN '' THEN [NodeAlias] ELSE @PrefixPath + '/' + [NodeAlias] END
				 ELSE @PrefixPath END AS NVARCHAR(2000)) 
				 AS Suffix,
			[NodeParentID],
			[NodeSiteID],
			[HasUrl],
			[HasUrl] AS IsRootPath
		FROM       
			[CMS_Tree] INNER JOIN @PageTypes ON [NodeClassID] = [ID]
		WHERE
			(@StartingNodeID IS NULL AND [NodeParentID] IS NULL AND [NodeSiteID] = @SiteID)
			OR (@StartingNodeID IS NOT NULL AND [NodeID] = @StartingNodeID)

		UNION ALL

		SELECT 
			[T].[NodeID],
			CAST(CASE [F].[HasUrl] 
				 WHEN 1 THEN CASE [P].[Suffix] WHEN '' THEN [T].[NodeAlias] ELSE [P].[Suffix] + '/' + [T].[NodeAlias] END
				 ELSE [P].[Suffix] END AS NVARCHAR(2000)) 
				 AS Suffix,
			[T].[NodeParentID],
			[T].[NodeSiteID],
			[F].[HasUrl],
			CAST(CASE WHEN [F].[HasUrl] = 1 AND [P].[Suffix] = '' THEN 1 ELSE 0 END AS BIT) AS IsRootPath
		FROM 
			[CMS_Tree] AS [T] INNER JOIN paths [P] ON [P].[NodeID] = [T].[NodeParentID] INNER JOIN @PageTypes AS [F] ON [NodeClassID] = [ID]
	)

	INSERT INTO @PreparedPaths ([CultureCode] , [NodeID], [UrlPath], [NodeSiteID], [IsRootPath])
		SELECT
			[CultureCode], 
			[NodeID], 
			CASE @UseCulturePrefix 
			WHEN 1 THEN 
				CASE WHEN [CultureCode] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
				THEN [Suffix] 
				ELSE [CultureCode] + '/' + [Suffix] END 
			ELSE [Suffix] END AS UrlPath, 
			[NodeSiteID],
			[IsRootPath]
		FROM
		(
			SELECT [NodeID], [Suffix], [NodeSiteID], C.Value as [CultureCode], [IsRootPath]  FROM paths CROSS JOIN @CultureCodes AS C WHERE [HasUrl] = 1
		) AS S

    BEGIN TRANSACTION
		BEGIN TRY
			INSERT INTO [CMS_PageUrlPath]([PageUrlPathGUID], [PageUrlPathCulture], [PageUrlPathNodeID], [PageUrlPathUrlPath], [PageUrlPathUrlPathHash], [PageUrlPathSiteID], [PageUrlPathLastModified])
				SELECT 
					NEWID(),
					[CultureCode],
					[NodeID],
					[UrlPath],
					CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([UrlPath])), 2),
					[NodeSiteID],
					@LastModified
				FROM @PreparedPaths
		END TRY
		BEGIN CATCH
			IF XACT_STATE() = 1
			BEGIN
				DECLARE @ParentsWithUrl TABLE(
					[CultureCode] NVARCHAR(50),
					[UrlPath] NVARCHAR(2000),
					[UrlPathWithHash] NVARCHAR(2000)
				)
				INSERT INTO @ParentsWithUrl ([CultureCode], [UrlPath], [UrlPathWithHash])
				SELECT 
					[CultureCode],
					[UrlPath],
					[UrlPath] + '-' + LOWER(CONVERT(VARCHAR(8), CRYPT_GEN_RANDOM(4), 2)) AS UrlPathWithHash
				FROM @PreparedPaths
				WHERE [IsRootPath] = 1

				INSERT INTO [CMS_PageUrlPath]([PageUrlPathGUID], [PageUrlPathCulture], [PageUrlPathNodeID], [PageUrlPathUrlPath], [PageUrlPathUrlPathHash], [PageUrlPathSiteID], [PageUrlPathLastModified])
					SELECT 
						NEWID(),
						[CultureCode],
						[NodeID],
						[UrlPathWithHash],
						CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([UrlPathWithHash])), 2),
						[NodeSiteID],
						@LastModified
					FROM
					(
						SELECT 
							[PreparedPath].[CultureCode],
							[PreparedPath].[NodeID],
							[Parent].[UrlPathWithHash] + SUBSTRING([PreparedPath].[UrlPath] , LEN([Parent].[UrlPath])  + 1, LEN([PreparedPath].[UrlPath]) - LEN([Parent].[UrlPath])) AS UrlPathWithHash,
							[PreparedPath].[NodeSiteID]
						FROM @PreparedPaths [PreparedPath]
						INNER JOIN @ParentsWithUrl [Parent] ON [PreparedPath].[UrlPath] LIKE [Parent].[UrlPath] + '%' AND [PreparedPath].[CultureCode] = [Parent].[CultureCode]
					) AS S
			END
			ELSE
			BEGIN
				ROLLBACK TRANSACTION	
			END
		END CATCH	
	COMMIT TRANSACTION
END
GO
