SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_PageUrlPath_UpdateUrlPaths]
	@OriginalUrlPath NVARCHAR(2000),
	@NewUrlPath NVARCHAR(2000),
	@CultureCode NVARCHAR(50),
	@OriginalSiteID INT,
	@NewSiteID INT,
	@LastModified DATETIME,
	@ResolveConfilcts BIT,
	@StoreFormerUrls BIT
AS
BEGIN
    BEGIN TRANSACTION
		BEGIN TRY
			EXEC [Proc_CMS_PageUrlPath_UpdateUrlPaths_Internal]
				@OriginalUrlPath = @OriginalUrlPath,
				@NewUrlPath = @NewUrlPath,
				@CultureCode = @CultureCode,
				@OriginalSiteID = @OriginalSiteID,
				@NewSiteID = @NewSiteID,
				@LastModified = @LastModified,
				@StoreFormerUrls = @StoreFormerUrls
		END TRY
		BEGIN CATCH
			IF XACT_STATE() = 1
			BEGIN
				IF @ResolveConfilcts = 1
				BEGIN
					DECLARE @NodeID AS INT = (SELECT TOP 1 [PageUrlPathNodeID] FROM [CMS_PageUrlPath] 
						WHERE [PageUrlPathUrlPathHash] = CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@OriginalUrlPath)), 2) AND [PageUrlPathCulture] = @CultureCode AND [PageUrlPathSiteID] = @OriginalSiteID)
					DECLARE @NodeGUID AS NVARCHAR(36) = CONVERT(NVARCHAR(36), (SELECT TOP 1 [NodeGUID] FROM [CMS_Tree] WHERE [NodeID] = @NodeID))

					SET @NewUrlPath = @NewUrlPath + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER(@NewUrlPath + @CultureCode + @NodeGUID)), 2))

					EXEC [Proc_CMS_PageUrlPath_UpdateUrlPaths_Internal]
						@OriginalUrlPath = @OriginalUrlPath,
						@NewUrlPath = @NewUrlPath,
						@CultureCode = @CultureCode,
						@OriginalSiteID = @OriginalSiteID,
						@NewSiteID = @NewSiteID,
						@LastModified = @LastModified,
						@StoreFormerUrls = @StoreFormerUrls
				END
				ELSE
				BEGIN
					DECLARE @NewValues TABLE(
					[PageName] NVARCHAR(100) NULL, 
					[CultureCode] NVARCHAR(50) NOT NULL, 
					[NodeID] INT NOT NULL, 
					[NewPath] NVARCHAR(2000) NOT NULL, 
					[NewPathHash] NVARCHAR(64) NOT NULL,
					[IsSelf] BIT NOT NULL,
					[Exists] BIT NOT NULL)

				INSERT INTO @NewValues 
					SELECT 
						[V].[DocumentName],
						[P].[PageUrlPathCulture],
						[P].[PageUrlPathNodeID],
						@NewUrlPath, 
						CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@NewUrlPath)), 2),
						1,
						CASE WHEN [V].[DocumentName] IS NULL THEN 0 ELSE 1 END
					FROM [CMS_PageUrlPath] AS [P]
					LEFT JOIN [View_CMS_Tree_Joined] AS [V] WITH (NOLOCK) ON [PageUrlPathNodeID] = [V].[NodeID] AND [PageUrlPathCulture] = [V].[DocumentCulture] 
					WHERE [PageUrlPathUrlPathHash] = CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@OriginalUrlPath)), 2) AND [PageUrlPathCulture] = @CultureCode AND [PageUrlPathSiteID] = @OriginalSiteID
					UNION
					SELECT 
						[V].[DocumentName],
						[P].[PageUrlPathCulture],
						[P].[PageUrlPathNodeID],
						@NewUrlPath + SUBSTRING([PageUrlPathUrlPath], LEN(@OriginalUrlPath) + 1, LEN([PageUrlPathUrlPath])), 
						CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@NewUrlPath + SUBSTRING([PageUrlPathUrlPath], LEN(@OriginalUrlPath) + 1, LEN([PageUrlPathUrlPath])))), 2),
						0,
						CASE WHEN [V].[DocumentName] IS NULL THEN 0 ELSE 1 END
					FROM [CMS_PageUrlPath] AS [P]
					LEFT JOIN [View_CMS_Tree_Joined] AS [V] WITH (NOLOCK) ON [PageUrlPathNodeID] = [V].[NodeID] AND [PageUrlPathCulture] = [V].[DocumentCulture] 
					WHERE [PageUrlPathUrlPath] LIKE @OriginalUrlPath + '/%' AND [PageUrlPathCulture] = @CultureCode AND [PageUrlPathSiteID] = @OriginalSiteID

				DECLARE @Collisions TABLE(
					[Path] NVARCHAR(2000) NOT NULL, 
					[PageName] NVARCHAR(100) NULL, 
					[CultureCode] NVARCHAR(50) NOT NULL, 
					[NodeID] INT NOT NULL, 
					[IsAlternative] BIT NOT NULL,
					[CultureVersionExists] BIT NOT NULL,
					[SourcePageName] NVARCHAR(100) NULL, 
					[SourceCultureCode] NVARCHAR(50) NOT NULL, 
					[SourceNodeID] INT NOT NULL, 
					[SourceIsSelf] BIT NOT NULL,
					[SourceCultureVersionExists] BIT NOT NULL)

				INSERT INTO @Collisions
					SELECT 
						[P].[PageUrlPathUrlPath],
						[V].[DocumentName],
						[P].[PageUrlPathCulture], 
						[P].[PageUrlPathNodeID],
						0, 
						CASE WHEN [V].[DocumentName] IS NULL THEN 0 ELSE 1 END,
						[N].[PageName],
						[N].[CultureCode],
						[N].[NodeID],
						[N].[IsSelf],
						[N].[Exists]
					FROM [CMS_PageUrlPath] AS [P] 
					INNER JOIN @NewValues AS [N] ON [P].[PageUrlPathUrlPathHash] = [N].[NewPathHash] AND [P].[PageUrlPathSiteID] = @OriginalSiteID
					LEFT JOIN [View_CMS_Tree_Joined] AS [V] WITH (NOLOCK) ON [P].[PageUrlPathNodeID] = [V].[NodeID] AND [P].[PageUrlPathCulture] = [V].[DocumentCulture] 
					UNION
					SELECT 
						[A].[AlternativeUrlUrl], 
						[D].[DocumentName],
						[D].[DocumentCulture], 
						[D].[DocumentNodeID], 
						1, 
						CASE WHEN [D].[DocumentName] IS NULL THEN 0 ELSE 1 END,
						[N].[PageName],
						[N].[CultureCode],
						[N].[NodeID],
						[N].[IsSelf],
						[N].[Exists]
					FROM [CMS_AlternativeUrl] AS [A] 
					INNER JOIN @NewValues AS [N] ON [A].[AlternativeUrlUrl] = [N].[NewPath] AND [A].[AlternativeUrlSiteID] = @OriginalSiteID
					INNER JOIN [CMS_Document] AS [D] ON [A].[AlternativeUrlDocumentID] = [D].[DocumentID] 
			
				SELECT * FROM @Collisions
				END
			END
			ELSE
			BEGIN
				ROLLBACK TRANSACTION	
			END
		END CATCH	
	COMMIT TRANSACTION
END

GO
