CREATE TYPE [Type_CMS_PageUrlPathsTable] AS TABLE(
	[CultureCode] [nvarchar](25) NOT NULL,
	[UrlPath] [nvarchar](2000) NOT NULL
)
GO