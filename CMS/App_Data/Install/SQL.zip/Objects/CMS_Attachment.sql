SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Attachment](
	[AttachmentID] [int] IDENTITY(1,1) NOT NULL,
	[AttachmentName] [nvarchar](255) NOT NULL,
	[AttachmentExtension] [nvarchar](50) NOT NULL,
	[AttachmentSize] [int] NOT NULL,
	[AttachmentMimeType] [nvarchar](100) NOT NULL,
	[AttachmentBinary] [varbinary](max) NULL,
	[AttachmentImageWidth] [int] NULL,
	[AttachmentImageHeight] [int] NULL,
	[AttachmentDocumentID] [int] NULL,
	[AttachmentGUID] [uniqueidentifier] NOT NULL,
	[AttachmentSiteID] [int] NOT NULL,
	[AttachmentLastModified] [datetime2](7) NOT NULL,
	[AttachmentIsUnsorted] [bit] NULL,
	[AttachmentOrder] [int] NULL,
	[AttachmentGroupGUID] [uniqueidentifier] NULL,
	[AttachmentFormGUID] [uniqueidentifier] NULL,
	[AttachmentHash] [nvarchar](32) NULL,
	[AttachmentTitle] [nvarchar](250) NULL,
	[AttachmentDescription] [nvarchar](max) NULL,
	[AttachmentCustomData] [nvarchar](max) NULL,
	[AttachmentSearchContent] [nvarchar](max) NULL,
	[AttachmentVariantDefinitionIdentifier] [nvarchar](50) NULL,
	[AttachmentVariantParentID] [int] NULL,
 CONSTRAINT [PK_CMS_Attachment] PRIMARY KEY NONCLUSTERED 
(
	[AttachmentID] ASC
)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_Attachment_AttachmentDocumentID_AttachmentIsUnsorted_AttachmentName_AttachmentOrder] ON [dbo].[CMS_Attachment]
(
	[AttachmentDocumentID] ASC,
	[AttachmentName] ASC,
	[AttachmentIsUnsorted] ASC,
	[AttachmentOrder] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Attachment_AttachmentDocumentID] ON [dbo].[CMS_Attachment]
(
	[AttachmentDocumentID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Attachment_AttachmentGUID_AttachmentSiteID] ON [dbo].[CMS_Attachment]
(
	[AttachmentGUID] ASC,
	[AttachmentSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Attachment_AttachmentIsUnsorted_AttachmentGroupGUID_AttachmentFormGUID_AttachmentOrder] ON [dbo].[CMS_Attachment]
(
	[AttachmentIsUnsorted] ASC,
	[AttachmentGroupGUID] ASC,
	[AttachmentFormGUID] ASC,
	[AttachmentOrder] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Attachment_AttachmentSiteID] ON [dbo].[CMS_Attachment]
(
	[AttachmentSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Attachment_AttachmentVariantParentID] ON [dbo].[CMS_Attachment]
(
	[AttachmentVariantParentID] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_Attachment_AttachmentVariantParentID_AttachmentVariantDefinitionIdentifier] ON [dbo].[CMS_Attachment]
(
	[AttachmentVariantDefinitionIdentifier] ASC,
	[AttachmentVariantParentID] ASC
)
WHERE ([AttachmentVariantDefinitionIdentifier] IS NOT NULL AND [AttachmentVariantParentID] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_Attachment]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Attachment_AttachmentDocumentID_CMS_Document] FOREIGN KEY([AttachmentDocumentID])
REFERENCES [dbo].[CMS_Document] ([DocumentID])
GO
ALTER TABLE [dbo].[CMS_Attachment] CHECK CONSTRAINT [FK_CMS_Attachment_AttachmentDocumentID_CMS_Document]
GO
ALTER TABLE [dbo].[CMS_Attachment]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Attachment_AttachmentSiteID_CMS_Site] FOREIGN KEY([AttachmentSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_Attachment] CHECK CONSTRAINT [FK_CMS_Attachment_AttachmentSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_Attachment]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Attachment_AttachmentVariantParentID_CMS_Attachment] FOREIGN KEY([AttachmentVariantParentID])
REFERENCES [dbo].[CMS_Attachment] ([AttachmentID])
GO
ALTER TABLE [dbo].[CMS_Attachment] CHECK CONSTRAINT [FK_CMS_Attachment_AttachmentVariantParentID_CMS_Attachment]
GO
