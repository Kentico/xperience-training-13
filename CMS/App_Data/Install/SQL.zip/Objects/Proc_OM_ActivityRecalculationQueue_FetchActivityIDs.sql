SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_OM_ActivityRecalculationQueue_FetchActivityIDs]
AS
BEGIN 
	SET NOCOUNT ON;

	DECLARE @DeletedIDs Type_OM_OrderedIntegerTable_DuplicatesAllowed

	DELETE TOP (10000) FROM [OM_ActivityRecalculationQueue] 
	OUTPUT deleted.ActivityRecalculationQueueActivityID 
	INTO @DeletedIDs

	SELECT * FROM OM_Activity INNER JOIN @DeletedIDs ON [OM_Activity].[ActivityID] = [@DeletedIDs].[Value]
END

GO
